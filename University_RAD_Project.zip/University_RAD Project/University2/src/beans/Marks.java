/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author Nithya
 */
public class Marks {
    private String course;
    private String mark;
    public String getCourse()
    {
        return course;
    }
    public void setCourse(String cou)
    {
        course=cou;
    }
     public String getMark()
    {
        return mark;
    }
    public void setMark(String m)
    {
        mark=m;
    }
}
